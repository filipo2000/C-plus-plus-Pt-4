#include <iostream>
#include <sstream>
#include <string>
#include "Array.h"


//Objective -> In this file we test the contents of the Array and Point Class

int main() {


	Array d; //Array class object d
	Point* a = new Point[10]; //Our pointer a which points to an array of pointers. The array is allocated on the heap via the new keyword
	Point*& s = a; //s is a reference of a

	for (int i = 0; i < 10; i++) { //Looping through d's array using d.m_data; We set each element within the array on the heap to Point(0,0); 
		d.SetElement(s, i);
		std::cout << d.GetElement(i) << std::endl;
	}

	int Asz = 6;
	Array q(Asz);
	q = d; //Now Array class object q holds the same counterparts as Array class object d
	std::cout << q[1] << std::endl; //1st Point class element in the array allocated on the heap which q.m_data pointer points to

	int Bsz = 6;
	const Array h(Bsz);
	std::cout << h[1] << std::endl; //Same idea as above but making the Array class object a const variable to test the const []


}





























