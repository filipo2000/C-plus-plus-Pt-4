//When we create objects by default they are saved in memory in our stack
//When we use the new keyword when creating/variables etc. they are saved in our memory in our heap

#include <iostream>
#include <sstream>
#include <string>
#include "Point.h"

//Objective-> In this file I will test the components of the Point class using variable alongside the key word new etc.
//The new keyword can be used on objects/variables; The new keyword returns a pointer we use this pointer to acess the variable that we declared + initlialized via the new keyword. Value of the pointer is the adress of the object in memory in the heap
//Delete keyword on a function with a class prohibits it from being used; Function decleration = delete;

//Creating an array in C++ syntax: data type name of array[num of elements in our arary]; This declares the arary; With a normal array in C++ the size is static = { element 1, element 2, ...}; This would initialize the array
//If we want to manipulate the sz we should create a dynamic aray using the new keyword/operator

//For classes, structs, and unions we use :: operator new instead of just plain new as we would for regular variables of built in type; Class objects can have their own new member function defined in the class

int main() {

	//The left side of the expression is the Pointers name; So p1 is a Pointer that points to a Point class object
	Point* p1 = new Point(); //Creating a new object using the key word new; The new keyword returns a pointer which points to this object in memory. The name of this Pointer here is called p1; Our newly declared object(right side of equals side) initiaties the default constructor since no arguments were provided hence it's m_x and m_y values will equal 0 as per the body of the default constructor
	Point* p2 = new Point(2, 5); //Similar to the above line except now our Point class object initiates the constructor which takes in 2 double parameters based on the arguments we have provided
	Point* p3 = new Point(*p2); //This initiates the copy constructor; Derefrencing the pointer gives us the Point class object that we want to copy to the Point class object that we are trying to create and that Pointer p3 is pointing to


//Calling the Distance() Functions

	std::cout << p1->Distance() << std::endl; //Derefrencing the pointer and accessing the Distance() Function is the same as calling the Distance() Function on the Point class object that Pointer p1 points to as derefrencing Pointer p1 gives us the Point class object
	std::cout << p2->Distance() << std::endl;
	std::cout << p3->Distance(*p2) << std::endl;; //This finds the distance between Point class object that Pointer p3 points to and Point class object that Pointer p2 points to


	//User input for Array Size
	int sz;
	std::cout << "Please enter the size that you'd like our Array to be: " << std::endl;
	std::cin >> sz;

	//Point check[sz];	//Compiler error as the size[] must be const for a standard array //(Array on the stack). Name of the array is check; We get a compiler error as the size of the array must be constant
	Point* p4 = new Point[sz]; //(Array on the heap).This creates a dynamic Array of Point class objects. This array is stored on the heap since we are using the new keyword. Point p4 points to this array of Points. The new keyword returns a pointer
	
	for (int i = 0; i < sz; i++) {
		p4[i] = Point(); //Setting each element in the array to a clean Point(0,0)
		p4[i].X(i); //Setting the X and Y aka m_x and m_y coordinates to i respectively
		p4[i].Y(i);
		std::cout << "Element " << i << " in array is:" << p4[i].ToString() << std::endl; //Testing the above lines 
	}


	//As per the for loop we are not restricted to the deafault constructor

	//Once we are done with our objects/variables that we created using the new keywrd we need to delete them using the delete keyword
	delete p1; //This deallocates the memory from the heap so now the objects created via the new keyword are no longer in the heap; The pointers p1,p2,p3 are now dangling/free pointers and ready to point at something else
	delete p2;
	delete p3;
	delete[] p4; //This frees up the memory that the array of Points took up on the heap

}