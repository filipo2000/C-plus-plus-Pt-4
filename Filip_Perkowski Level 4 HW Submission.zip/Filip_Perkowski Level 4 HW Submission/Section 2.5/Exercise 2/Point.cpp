#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Point.h"

//Objective -> This file defines all the components within the Point Class

//Starting by defining our Constructors and Deconstructor
Point::Point() {
	m_x = 0;
	m_y = 0;
}


Point::Point(double a, double b) {
	m_x = a;
	m_y = b;
}

Point::Point(const Point& c) {
	m_x = c.m_x;
	m_y = c.m_y;
}

Point::~Point() {

}

//Get() Functions
double Point::X() const {
	return m_x;
}

double Point::Y() const {
	return m_y;
}

//Set() Functions
void Point::X(const double& a) {
	m_x = a;
}

void Point::Y(const double& b) {
	m_y = b;
}

//ToString() Function
std::string Point::ToString() const {
	std::stringstream a;
	a << "Point(" << m_x << "," << m_y << ")" << std::endl;
	return a.str();
}

//Distance() Functions
double Point::Distance() const {
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
}

double Point::Distance(const Point& c) const {
	return sqrt(pow(m_x - c.m_x, 2) + pow(m_y - c.m_y, 2));
}

//Operator Functions
Point Point::operator-() const {
	Point c(-m_x, -m_y); //m_x and m_y reffer to the x and y coordinates of the underlying Point object that initiates the operator function
	return c;
}

Point Point::operator*(double factor) const { //Ex: Point d = e * 2; Point d holds component values of that of Point c; Point d = Point c from the return value
	Point c(m_x * factor, m_y * factor); //We create a whole new Point class object and initiazlise it's x and y coordinates to m_x * factor and m_y * factor
	return c;
}

Point Point::operator+(const Point& c) const {
	Point s(m_x + c.m_x, m_y + c.m_y);
	return s;
}

bool Point::operator==(const Point& c) const {
	if (m_x == c.m_x && m_y == c.m_y) {
		return true; //Both our underlying Point class object and the Point object argument are equal
	}
	else {
		return false; //They are not equal
	}
}

Point& Point::operator=(const Point& c) { //Point d = a; Where both d and a are Point objects. Point d objects gets the m_x and m_y values from Point a; Function returns the left hand side so d in this case would get returned
	m_x = c.m_x;
	m_y = c.m_y;
	return *this; //This returns the underlying Point object used to initiate this = operator function
}


Point& Point::operator*=(double factor) {
	this->m_x = this->m_x * factor;
	this->m_y = this->m_y * factor;
	return *this;
}



//Friend Function Defined
std::ostream& operator<< (std::ostream& o, const Point& c) {
	o << c;
	return o;
}