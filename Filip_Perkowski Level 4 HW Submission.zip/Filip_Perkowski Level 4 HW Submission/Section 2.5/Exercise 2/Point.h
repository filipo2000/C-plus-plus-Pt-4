#pragma once

#ifndef Point_h
#define Point_h

#include <iostream>
#include <sstream>
#include <string>
#include <cmath>

//Objective -> This is our file which contains all the components within the Point Class

//Adding the set of operator functions

class Point {
private:
	double m_x;
	double m_y;
public:
	//Constructors and Deconstructor
	Point();
	Point(double a, double b);
	Point(const Point& b);
	~Point();

	//Get() Functions
	double X() const;
	double Y() const;

	//Set() Functions
	void X(const double& a);
	void Y(const double& b);
		
	//ToString() Function
	std::string ToString() const;

	//Distance() Functions
	double Distance() const;
	double Distance(const Point& c) const;

	//Operator Functions
	Point operator-() const;
	Point operator*(double factor) const;
	Point operator+(const Point& c) const;
	bool operator==(const Point& c) const;
	Point& operator =(const Point& source);
	Point& operator*=(double factor);


	//Friend Function
	friend std::ostream& operator<<(std::ostream& o, const Point& c);
};



#endif