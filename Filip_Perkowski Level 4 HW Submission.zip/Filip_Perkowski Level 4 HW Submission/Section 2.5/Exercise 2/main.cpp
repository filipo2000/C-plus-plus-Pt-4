#include <iostream>
#include <sstream>
#include <string>
#include "Point.h"

//Now we want to create an array of pointers. So the arrays elements are pointers
//Adress of the array in memory = Adress of the 1st element in memory

int main() {

	//Point* per[10]; Default C++ Array containing 10 Pointers; The name of the Array is per
	//Now creating an array of which consists of 3 Point pointers on the heap(so it should be a dynamic array) aka the size of the array can change
	const int size = 3; //Holds the value of the size of the dynamic array allocated onto the heap
	Point** arr = new Point*[size]; //arr is a pointer that looks at pointers one by one; Hence arr is a pointer to the 2nd level hence the 2 **'s. Elements of the array(the array object is now alloacated in the heap via the new keyword) are pointers

	for (int i = 0; i < size; i++) {
		arr[i] = new Point(i + 1, i + 1); //Indexing the pointer to a pointer give us the pointers within the array. Each respective array element aka pointer looks at an independent Point object that's allocated onto the heap with m_x and m_y values of i + 1; //Each Pointer object aka element in the array points to a point object of x_cord and y_cord of 10 and 20 respectively
		std::cout << (*arr[i]).ToString() << std::endl;
	}


	for (int i = 0; i <= 2; i++) { //For loop to delete all of our elemenets within our array one by one
		delete arr[i]; //This dealocates from the heap the Point objects that the array elements aka Pointers were pointing to
	}

	delete arr; //This delete the 2nd degree pointer named arr


}

