#include "Point.h"
#include <cmath>
#include <string>
#include <sstream>

using namespace Filip::CAD; //Use directive towards the inner most scoped namespace in which the Point class is declared in the Point.h file; This way the compiler for sure knows we are reffering to the proper Point class

//Objective -> In this file I define all the components within the Point class

Point::Point() : m_x(0), m_y(0) {

}

Point::Point(double a, double b): m_x(a), m_y(b) {

}


Point::Point(const Point& c) {
	m_x = c.m_x;
	m_y = c.m_y;
}

Point::~Point() {

}

//

double Point::X() const {
	return m_x;
}

double Point::Y() const {
	return m_y;
}

//
void Point::X(double a) {
	m_x = a;
}

void Point::Y(double b) {
	m_y = b;
}

std::string Point::ToString() const {
	std::stringstream a, b;
	a << m_x;
	b << m_y;
	std::string resi = "Point(" + a.str() + "," + b.str() + ")";
	return resi;
}

//

double Point::Distance() const {
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
}

double Point::Distance(const Point& c) const {
	return sqrt(pow(m_x - c.m_x, 2) + pow(m_y - c.m_y, 2));
}

//Operator Functions

Point Point::operator-() const {
	Point c(-m_x, -m_y);
	return c;
}

Point Point::operator*(double factor) const {
	Point c(m_x * factor, m_y * factor);
	return c;
}

Point Point::operator+(const Point& p) const {
	Point c(m_x + p.m_x, m_y + p.m_y);
	return c;
}

bool Point::operator==(const Point& p) const {
	if (m_x == p.m_x) {
		return true;
	}
	else {
		return false;
	}
}

Point& Point::operator=(const Point& source) {
	if (this == &source) {
		return *this;
	}
	else {
		m_x = source.m_x;
		m_y = source.m_y;
		return *this;
	}
}

Point& Point::operator*=(double factor) {
	this->m_x = m_x * factor;
	this->m_x = m_x * factor;
	return *this;
}

std::ostream& operator<<(std::ostream& o, const Point& p) {
	o << p.ToString();
	return o;
}