#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include "Array.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

//using directives
using Filip::CAD::Line; //Fetching the Line Class
using namespace Filip::Containers; //Fetching the Container Class
namespace resi = Filip::CAD; //Namespace Alias
using resi::Circle; //Fetching the Circle class using the Alias

//using namespace Filip; Although it's logically correct(it's an error in C++), always use the namespace that's of closest/inner scope to the variable that we want to reffer to this is because 
//within namespace Filip you could have other namespaces which have the same variable name and the compiler doesn't know which one we want to reffer to if we include namespace [outer namespace name];

//Objective -> In this file we test the namespaces + components of our class at once

int main() {

	Filip::CAD::Point p1(1, 1); //Using the :: notation among namespaces to fetch the Point Class(Full namespace for the Point Class)
	Filip::CAD::Point p2(2, 2);
	//std::cout << p1 << std::endl;
	//std::cout << p2 << std::endl;

	
	Line p(p1, p2);
	std::cout << p << std::endl;

	Array t(2); //2 is the size of our Array class object
	t[0] = p1;
	t[1] = p2;

	std::cout << t[0] << std::endl;
	std::cout << t[1] << std::endl;

	Circle c1(p1, 5);
	std::cout << c1;

	Filip::CAD::Point p4(10, 20);
	//std::cout << p4.X() << "," << p4.Y();


	Line l1(p2, p4);
	std::cout << l1.ToString() << std::endl;
	//std::cout << l1.P1().X() << l1.P1().Y() << l1.P2().X() << l1.P2().Y() << std::endl;

	Circle c6(p4, 3);
	std::cout << c6.ToString() << std::endl;


}