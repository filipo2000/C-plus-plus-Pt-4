#include "Point.h"
#include "Array.h"

using namespace std;
using namespace Filip;
using namespace Containers;

//this.m_data and m_data are the same thing since this is a pointer pointing to the underlying object that initiated the function within the class

//Now given that we have namespaces we need to include the appropriate header file + appropriate namespaces; CAD::Point individually or using Filip::CAD; on top

//Objective -> Here we define all the contents within the Array class
//We could also do -> include Filip::CAD::Point instead the explicit CAD::Point for each Point instance

Array::Array() {
	m_data = new CAD::Point[10];
	m_size = 10;
}

Array::Array(int sz) {
	m_data = new CAD::Point[sz];
	m_size = sz;
}

Array::Array(const Array& c) {
	m_size = c.m_size;
	m_data = new CAD::Point[m_size]; 

	for (int i = 0; i < m_size; i++) {
		m_data[i] = c.m_data[i];
	}

}

Array::~Array() {

}

//Size() Function()
int Array::Size() const {
	return m_size;
}

void Array::SetElement(CAD::Point* p, int index) {
	if (index > 0 && index < m_size) {
		m_data[index] = (*p);
	}
}
		
CAD::Point& Array::GetElement(int index) const {
	if (index >= m_size || index < 0) {
		return m_data[0];
			}
	else {
		return m_data[index];
			}
		}

Array& Array::operator=(const Array & c) {
	if (this == &c) {
		return *this;
			}
	delete[] m_data;
		m_size = c.m_size;
		m_data = new CAD::Point[m_size]; //Make our pointer m_data point to a new array allocated on the heap
		for (int i = 0; i < m_size; i++) {
			m_data[i] = c.m_data[i];
			}
			return *this;
		}

CAD::Point& Array::operator[](int index) {
	if (index >= m_size || index < 0) {
		return this->m_data[0];
			}
		else {
			return this->m_data[index];
			}
		}

const CAD::Point& Array::operator[](int index) const {
	if (index >= m_size || index < 0) {
		return this->m_data[0];
			}
	else {
		return this->m_data[index];
			}
		}
	