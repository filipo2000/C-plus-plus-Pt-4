#define _USE_MATH_DEFINES
#include "Circle.h"
#include <cmath>
#include <sstream>

using namespace Filip::CAD;
//We could alternatively do use Filip::CAD::Circle, use Filip::CAD::Point but the top line is more efficient

//Objective -> In this file, we define all the elements within the Circle class

//Constructors + Deconstructor
Circle::Circle() {
	Point c_point();
	c_radius = 0;
}

Circle::Circle(const Point& a, const double& b) {
	c_point = a;
	c_radius = b;
}

Circle::Circle(const Circle& c) {
	c_point = c.c_point;
	c_radius = c.c_radius;
}

Circle::~Circle() {

}

//Get() and Set() Functions
Point Circle::CentrePoint() const {
	return c_point;
}

double Circle::Radius() const {
	return c_radius;
}

//
void Circle::CentrePoint(const Point& p1) {
	c_point = p1;
}

void Circle::Radius(const double& p2) {
	c_radius = p2;
}


//ToString() Function
std::string Circle::ToString() const {
	std::stringstream a;
	a << c_radius;
	std::string resi = "Circle with radius " + a.str() + " and center at " + c_point.ToString();
	return resi;
}

//Measurement Functions() 
double Circle::Area() const {
	return M_PI * pow(c_radius, 2);
}

double Circle::Diameter() const {
	return c_radius * 2;
}

double Circle::Circumfrence() const {
	return M_PI * 2 * c_radius;
}

//= operator function()
Circle& Circle::operator=(const Circle& c) {
	if (this == &c) {
		return *this;
	}
	else {
		c_point = c.c_point;
		c_radius = c.c_radius;
		return *this;
	}
}
//<< operator function() that outside the class
std::ostream& operator<<(ostream& o, const Circle& c) {
	o << c.ToString();
	return o;
}