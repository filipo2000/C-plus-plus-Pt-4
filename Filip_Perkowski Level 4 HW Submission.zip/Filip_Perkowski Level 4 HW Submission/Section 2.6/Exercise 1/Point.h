#ifndef Point_h
#define Point_h

#include <iostream>
#include <sstream>
#include <string>
using namespace std;

namespace Filip {
	namespace CAD {
		class Point {
			private:
				double m_x;
				double m_y;
			public:
				Point();
				Point(double x, double y);
				Point(const Point& c);
				~Point();

				//Get() Function
				double X() const;
				double Y() const;

				//Set() Functions
				void X(double a);
				void Y(double b);

				//ToString()
				std::string ToString() const;

				//Distance()
				double Distance() const;
				double Distance(const Point& p) const;

				//Opertaor
				Point operator-()const;
				Point operator*(double factor) const;
				Point operator+(const Point& c) const;
				bool operator==(const Point& c) const;
				Point& operator=(const Point& source);
				Point& operator*=(double factor);
		};
	}

}


std::ostream& operator<<(std::ostream& o, const Filip::CAD::Point& p);





























#endif
