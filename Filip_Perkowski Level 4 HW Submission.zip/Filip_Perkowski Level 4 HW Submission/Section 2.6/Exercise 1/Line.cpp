#include "Line.h"
#include <iostream>
#include <sstream>
#include <cmath>
#include <string>

using namespace Filip::CAD;

//Objective -> Here we define all the components within the Line class

Line::Line() {

}

Line::Line(const Point& a, const Point& b) {
	s_point = a;
	e_point = b;
}

Line::Line(const Line& c) {
	s_point = c.s_point;
	e_point = c.e_point;
}

Line::~Line() {

}

//Get() Functions
Point Line::P1() const {
	return s_point;
}

Point Line::P2() const {
	return e_point;
}

//Set() Functions
void Line::P1(const Point& a) {
	s_point = a;
}

void Line::P2(const Point& b) {
	e_point = b;
}

//ToString() 
std::string Line::ToString() const {
	std::string resi;
	resi = "Line between " + s_point.ToString() + " and " + e_point.ToString();
	return resi;
}

double Line::Length() const {
	return s_point.Distance(e_point);
}

Line& Line::operator=(const Line& source) {
	if (this == &source) {
		return *this;
	}
	s_point = source.s_point; //Indirect else{}
	e_point = source.e_point;
	return *this;

}

std::ostream& operator<<(std::ostream& o, const Line& c) {
	o << c.ToString();
	return o;
}