#ifndef Circle_h
#define Circle_h


#include "Point.h"
#include <iostream>

using namespace std;

//Objective -> In this file we declare all the components within the Circle class

namespace Filip {
	namespace CAD {
		class Circle {
			private:
				Point c_point;
				double c_radius;
			public:
				Circle();
				Circle(const Point& a, const double& b);
				Circle(const Circle& c);
				~Circle();

				//
				Point CentrePoint() const;
				double Radius() const;

				//Se
				void CentrePoint(const Point& p1);
				void Radius(const double& p2);

				//M
				double Area() const;
				double Diameter() const;
				double Circumfrence() const;

				std::string ToString() const;

				Circle& operator=(const Circle& c);
		
		};
	}
}


std::ostream& operator<<(std::ostream& o, const Filip::CAD::Circle& c);




#endif