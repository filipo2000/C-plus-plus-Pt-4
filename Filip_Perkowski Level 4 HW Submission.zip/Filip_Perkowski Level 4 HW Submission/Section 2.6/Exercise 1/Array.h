#ifndef Array_h
#define Array_h

#include "Point.h"


namespace Filip {
	namespace Containers {
		class Array {
			private:
				CAD::Point* m_data; //Since Point is wihtin the CAD namespace we need to do CAD:: individuall or using Filip::CAD::Point or using namespace Filip::CAD
				int m_size;
			public:
				Array();
				Array(int sz);
				Array(const Array& c);
				~Array();

				//Functions() which will work on the underlying Array class object
				int Size() const;
				void SetElement(CAD::Point* p, int index);
				CAD::Point& GetElement(int index) const;

				Array& operator=(const Array& source);

				CAD::Point& operator[](int index);
				const CAD::Point& operator[](int index) const;
		};
	}
}

#endif
