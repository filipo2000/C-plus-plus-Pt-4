#ifndef Line_h
#define Line_h

#include "Point.h"
#include <iostream>
#include <string>

using namespace std;

//Objective -> In this file we declare all the components within the Line class

namespace Filip {
	namespace CAD {
		class Line {
			private:
				Point s_point;
				Point e_point;
			public:
				//Constructors + Deconstructor
				Line();
				Line(const Point& a, const Point& b);
				Line(const Line& c);
				~Line();
				
				//Get() Function
				Point P1() const;
				Point P2() const;

				//Set() Function
				void P1(const Point& p1);
				void P2(const Point& p2);

				//ToString() 
				std::string ToString() const;

				//Length()
				double Length() const;

				Line& operator=(const Line& source);


		};
	}
}

std::ostream& operator<<(std::ostream& o, const Filip::CAD::Line& p);



#endif
