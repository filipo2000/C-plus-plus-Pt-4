#include <iostream>
#include <sstream>
#include <string>
#include "Point.h"

//Objective -> This is our main function, this is where we test all the properties within our Point Class

int main() {

	Point p(1.0, 1.0); 
	
	if (p == (Point)1.0) {
		std::cout << "Equal!!" << std::endl;
	}
	else {
		std::cout << "Not Equal!!" << std::endl;
	}
//The code above did not run initially; However, after the changes it now runs fine 




}