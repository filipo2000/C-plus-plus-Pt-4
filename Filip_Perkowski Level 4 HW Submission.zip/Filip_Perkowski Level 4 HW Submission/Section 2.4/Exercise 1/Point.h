#pragma once

#ifndef Point_h
#define Point_h

#include <iostream>
#include <sstream>
#include <string>
#include <cmath>

//Objective -> This is our file which contains all the components within the Point Class

//Adding the set of operator functions

class Point {

	private: //Our components within a Point Class object
		double m_x;
		double m_y;

	public:
		//Our constructors + deconstructor
		Point();
		Point(double a, double b);
		Point(const Point& p);
		~Point();

		//Our Get() Functions
		double X() const;
		double Y() const;

		//Our Set() Functions 
		void X(const double& a);
		void Y(const double& b);
		

		//ToString() Function; This function returns a string description a Point Class object that calls it
		std::string ToString() const;

		//Distance() Functions;
		double Distance() const; //Calculatess the distance between the Point object that calls it via the . operator and origin
		double Distance(const Point& p) const; //Caclulates the distance between the Point object that calls it via the . operator and the Point object passed via argument
		  
		//Our Operator Functions; Each of these operator functions will tell us how these operators behave when used alongiside objects of Point class type
		Point operator -() const;
		Point operator *(double factor) const;
		Point operator + (const Point& p) const;
		bool operator ==(const Point& p) const;
		Point& operator =(const Point& source);
		Point& operator *=(double factor);




};

		


#endif

