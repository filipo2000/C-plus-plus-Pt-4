#pragma once

#ifndef Line_h
#define Line_h

#include <sstream>
#include <iostream>
#include <string>
#include "Point.h"

//Objective -> This file is the header file and it depicts all the components of the Line class
//Adding the = opearator function

class Line {
	private:
		Point start; //These are the 2 components of a Line class object. AKA every Line class object will contain a start and end Point class object
		Point end;
	public:
		//Our constructors and deconstructor
		Line(); //Default Constructor
		Line(Point a, Point b); //Constructor which takes 2 double arguments
		Line(const Line& c); //Copy Constructor
		~Line(); //Deconstructor

		//Get() Functions
		Point P1() const; //These functions return the start point and end point respectively
		Point P2() const;

		//Set() Functions
		void P1(const Point& a); //These functions set the value of start and end to a and b respectively
		void P2(const Point& b);
		
		//ToString() Function
		std::string ToString() const; //Our ToString() function returns a string which describes our Line class object

		//= Operator Function
		Line& operator=(const Line& c); //This function isnin't const as we are potentially changing the componenets of the underlying line class object
		

		//Length() Function
		double Length() const; //This function returns the length of the Line class object aka the distance between the start and end Point of a given Line class object

	
};

		

#endif