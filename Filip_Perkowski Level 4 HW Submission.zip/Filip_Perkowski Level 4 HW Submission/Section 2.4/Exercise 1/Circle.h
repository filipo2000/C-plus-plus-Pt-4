#pragma once

#ifndef Circle_h
#define Circle_h

#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Line.h" //By includeing this we are also indirectly include the Point header file as the Line header file itself include the Point header file. So we are killing 2 birds with one stone

//Objective -> Our file here defines all the properties in the Circle class
//When we have a reference return type our return value is a reference itself if a function is name add and has return z; and return type is int&; Then add() = d; This means z = d; So z holds d's value. Assumingly z is a refference for a now a hold's d's value since z is a synonym for a 

//Adding the = operator function

class Circle {
	private: 
		Point m_point; //Each Circle class object will have it's own set of Point class object and Line class object in addition to it's own set of the below functions 
		Line m_radius;
	public:
		//Our constructors and deconstructor
		Circle();
		Circle(Point a, Line b);
		Circle(const Circle& c);
		~Circle();

		//Get() Functions
		Point CentrePoint() const;
		Line Radius() const;
		
		//Set() Functions
		void CentrePoint(const Point& a);
		void Radius(const Line& b);

		//ToString Function()
		std::string ToString() const;

		//Measurement Functions
		double Area() const;
		double Diameter() const;
		double Circumfrence() const;

		//= operator function
		Circle& operator=(const Circle& c);


};


#endif
