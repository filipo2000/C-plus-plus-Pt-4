#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Point.h"

//Objective -> This is our .cpp file where we will define all the contents within the Point class

//Starting by defining our constructor set and deconstructor
Point::Point() {
	m_x = 0;
	m_y = 0;
}

Point::Point(double a, double b) {
	m_x = a;
	m_y = b;
}

Point::Point(const Point& c) {
	m_x = c.m_x;
	m_y = c.m_y;
}

Point::~Point() {
	//std::cout << "This is the deconstructor!!" << std::endl;
}

//Get() Functions
double Point::X() const {
	return m_x;
}

double Point::Y() const {
	return m_y;
}

//Our Set() Functions
void Point::X(const double& a) {
	m_x = a;
}

void Point::Y(const double& b) {
	m_y = b;
}

//Our ToString() Function
std::string Point::ToString() const {
	std::stringstream a;
	a << "Point:(" << m_x << "," << m_y << ")";
	return a.str();
}

//Defining our Distance() Functions
double Point::Distance() const {
	return sqrt(pow(m_x - 0, 2) + pow(m_y - 0, 2));
}


//Now Defining Our Overloaded Functions; Here the left hand operand to the operator is usually the underlying object aka the one that would use the . opeartor to acess a function the right hand operator is the argument value
double Point::Distance(const Point& p) const {
	return sqrt(pow(m_x - p.m_x, 2) + pow(m_y - p.m_y, 2)); //This new Point object created in the body and returned is to the left of the = sign in the source file when we write an equation include one of these operators(aka initiating it)
}

Point Point::operator-() const {
	Point a(-m_x, -m_y); //We are creating a seperate new Point class object proiding it component values and returning it
	return a;
}

Point Point::operator*(double factor) const {
	Point a(m_x * factor, m_y * factor);
	return a;
}

Point Point::operator+(const Point& p) const {
	Point a(m_x + p.m_x, m_y + p.m_y);
	return a;
}


bool Point::operator==(const Point& p) const {
	if (m_x == p.m_x && m_y == p.m_y) {
		return true;
	}
	else {
		return false;
	}
}


Point& Point::operator=(const Point& source) { //Last two operator functions shouldn't be const functions as we are changing the components of the underlying Line object that calls the opreator function 
	if (this != &source) {
		m_x = source.m_x;
		m_y = source.m_y;
		return *this;
	}
	else {
		return *this; //This derefrence gives us the value of the Point object(aka the object that the pointer is pointing to)
	}
	
	
}

Point& Point::operator*=(double factor) {
	this->m_x = this->m_x * factor; //Scaling/Multiplying the underlying Point object m_x and m_y by the value of factor
	this->m_y = this->m_y * factor;
	return *this;
}