#define _USE_MATH_DEFINES 
#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include "Circle.h"

//The define keyword should be a line above the cmath header file
//Objective -> In this file we define all the components within the Circle class

//If our function call returns a reference then our function call can be on the left side of an assignment (=) expression; Ex: fact() = d; where fact() is the function call is d is a variable

//Starting with our constructors and deconstructor
Circle::Circle() { //Since we are defining public members of the Circle class here we can freely include our private members of the Circle class
	Point();
	Line();
}

Circle::Circle(Point a, Line b) {
	m_point = a;
	m_radius = b;
}

Circle::Circle(const Circle& c) {
	m_point = c.m_point;
	m_radius = c.m_radius;
}

Circle::~Circle() {
	
}

//Get() Functions
Point Circle::CentrePoint() const {
	return m_point;
}

Line Circle::Radius() const {
	return m_radius;
}

//Set() Functions
void Circle::CentrePoint(const Point& a) {
	m_point = a;
}

void Circle::Radius(const Line& b) {
	m_radius = b;
}

//ToString() Function
std::string Circle::ToString() const {
	std::stringstream a, b;
	a << "Circle object has Center Point (" << m_point.X() << "," << m_point.Y() << ")";
	b << " and Line with Points (" << m_radius.P1().X() << "," << m_radius.P1().Y() << ")" << "and" << "(" << m_radius.P2().X() << "," << m_radius.P2().Y() << ")";
	std::string resi = a.str() + b.str();
	return resi;
}

//Our Measurement Functions
double Circle::Area() const {
	return M_PI * pow(m_radius.Length(), 2); //Area of a circle is pi * r^2
}

double Circle::Diameter() const {
	return m_radius.Length() * 2;
}

double Circle::Circumfrence() const {
	return 2 * M_PI * m_radius.Length();
}

//Operator = function
Circle& Circle::operator=(const Circle& c) {
		if (this == &c) {
			return *this;
		}
		else {
			m_radius = c.m_radius;
			m_point = c.m_point;
			return *this;
		}
	}
