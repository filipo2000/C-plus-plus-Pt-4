#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include "Circle.h"

//Objecitve-> In this file we test the components within the Point, Line and Circle class especially the operator function in the Point Class

//Operator functions within a class give meaning to an operator when used alongisde objects of a class type. Ex: An + operator function in our Point class defines what a +(the + sign) means/should do when we use it on object of Point class type
//The const operator functions are not allowed to change the properties of the Point class object that uses the . opreator to access this function. As a result, what's often done is we return a new independent Point class object whose value/properties are that of the Point class object that calls the overloaded function + tweaked slightly. Tweak is expressed in the body of the function

//We can't redefine a Point object multiple times aka use a constructor more than once for an individual object

int main() {

	//Testing Point objects; Testing Line objects and Circle objects is the same idea

	Point p1(1,2);
	Point p2(7, 12);
	Point p4(10, 20);
	Point p3 = p1 + p2; //Testing the + operator function
	std::cout << p3.X() << "," << p3.Y() << std::endl;

	double a = -p2.X(); //Testing the - operator function
	std::cout << a;

	Point z = p3 * 2; //Testing the * operator function
	std::cout << z.ToString() << std::endl;

	bool resi = p1 == p2; //p1 is not equal to p2 hence this returns false
	std::cout << resi << std::endl;

	Point j = z; //Using the = operator
	std::cout << j.X() << "," << j.Y() << std::endl;

	//Testing the *= operator
	Point l = p1 * 2; //Testing the *= operator
	std::cout << l.ToString() << std::endl;

	//Testing Line objects

	Line l1(p1, p2);
	std::cout << l1.ToString() << std::endl;

	l1.P1(p4); //This will change Line objects p1 Point coordinate to p3;
	l1.P2(p1); //This should change Line objects P1 p2 Point coordinate to p1;

	//Testing the above Set() Functions using the Get() Functions
	std::cout << "Our line object l1 has Points (" << l1.P1().X() << "," << l1.P1().Y() << ")" << "and " << "Point (" << l1.P2().X() << "," << l1.P2().Y() << ")" << std::endl;

	std::cout << l1.Length() << std::endl; //This will output the length of the line aka the distance between the Line's object 2 Point in this case Point p1 and p4

	Line l2 = l1; //Using the = operator
	std::cout << l2.P1().X() << std::endl; //Output 10 the x coordinate of Point p4 which is the starting point of Line object l2; Line object l2 gets the same value of l1 through the = operator
	


	//Testing the Circle objects
	Circle c1(p1, l1); //Initiates the constructor which takes in a Point and Line argument
	Circle c2; //This initiates the default constructor; Contains point 0,0- origin point and non existent line
	Circle c3(p4, l2);
	Circle c4(c1); //Initiates the copy constructor

	//Testing the CentrePoint() and Radius() Get() Functions
	std::cout << c1.CentrePoint().X() << "," << c1.CentrePoint().Y() << std::endl;
	std::cout << c1.Radius().P1().X() << "," << c1.Radius().P1().Y() << "," << c1.Radius().P2().X() << "," << c1.Radius().P2().Y() << std::endl;
	
	//Testing the CentrePoint() and Radius Set() Functions
	c3.CentrePoint(p2); //Now the centere point of the c3 Class Circle object is p2
	c3.Radius(l1); //Now the radius/line object within c3 Class Circle object is l1
	
	//Verifying this using the ToString() Function
	std::cout << c3.ToString() << std::endl;

	//Testing the Measurement Functions 
	std::cout << c4.Area() << " " << c1.Area() << std::endl;
	std::cout << c4.Circumfrence() << std::endl;
	std::cout << c4.Diameter() << std::endl;

	//Testing the = operator function; Since we are using the = operator alongside Circle class objects; If we were to use an operator(=, * etc.) alongiside C++ defined type variables like int, char etc. then interaction would be C++ defined
	Circle c5 = c1;
	std::cout << c5.CentrePoint().X() << std::endl;


}









































