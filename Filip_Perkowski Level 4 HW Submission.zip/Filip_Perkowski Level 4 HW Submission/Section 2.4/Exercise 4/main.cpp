#include <iostream>
#include <sstream>
#include <string>
#include "Line.h"
#include "Point.h"

//Objective -> In this file we determine the validity of the components within our: Point, Line and Circle classes
//Value returned/spitted back when calling the function()

int main() {

	Point p1(5, 2);
	Point p2(30, 10);
	//std::cout << p1.X() << "," << p1.Y() << std::endl;
	std::cout << p1 << std::endl; //Testing the << operator; Work well as a friend function

	Line l1(p1, p2);
	std::cout << l1; //Works well

	

}