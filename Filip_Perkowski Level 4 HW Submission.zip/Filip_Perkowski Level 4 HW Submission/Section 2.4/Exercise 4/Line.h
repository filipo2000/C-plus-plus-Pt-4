#ifndef Line_h
#define Line_h

#include "Point.h"
#include <iostream>
#include <string>

using namespace std;

//Objective -> In this file we declare all the components within the Line class

class Line {
	private:
		Point s_point;
		Point e_point;
	public:
		//Constructor and Deconstructor
		Line();
		Line(const Point& p1, const Point& p2);
		Line(const Line& c1);
		~Line();

		//Get() Functions
		Point P1() const;
		Point P2() const;

		//Set() Functions
		void P1(const Point& p1);
		void P2(const Point& p2);

		//ToString() Functions
		std::string ToString() const;

		//Length() Function
		double Length() const;

		//Operator = function
		Line& operator=(const Line& c);

		friend std::ostream& operator<<(ostream& o, const Line& p); //Our friend function now it's within the brakets but it's still technically not a function within the class


};




#endif