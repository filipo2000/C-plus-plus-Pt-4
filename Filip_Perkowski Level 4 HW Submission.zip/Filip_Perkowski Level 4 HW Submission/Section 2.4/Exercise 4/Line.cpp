#include "Line.h"
#include <cmath>
#include <sstream>

//Objective -> In this file we define all the components within our Line class

Line::Line() {

}

Line::~Line() {

}

Line::Line(const Point& p1, const Point& p2) {
	s_point = p1;
	e_point = p2;
}

Line::Line(const Line& c) {
	s_point = c.s_point;
	e_point = c.e_point;
}


//Get() Functions
Point Line::P1() const {
	return s_point;
}

Point Line::P2() const {
	return e_point;
}

//Set() Functions
void Line::P1(const Point& p1) {
	s_point = p1;
}

void Line::P2(const Point& p2) {
	e_point = p2;
}

std::string Line::ToString() const {
	std::stringstream a,b;
	a << "Point(" << s_point.X() << "," << s_point.Y() << ") ";
	b << "and Point(" << e_point.X() << "," << e_point.Y() << ")";
	std::string resi = "Line contains: " + a.str() + b.str();
	return resi;
}

double Line::Length() const{
	return s_point.Distance(e_point);
}

Line& Line::operator=(const Line& source) {
	if (this == &source) {
		return *this;
	}
	s_point = source.s_point;
	e_point = source.e_point;
	return *this;
}

std::ostream& operator<<(ostream& o, const Line& s) {
	o << s.ToString();
	return o;
}