#include <iostream>
#include <sstream>
#include <string>
#include "Circle.h"

//Objective -> In this .cpp we test the components of the Point, Circle, and Line class

//IMPORTANT: FOR SOME REASON LINE OBJECTS AND CIRCLE OBJECTS AREN'T MADE CORRECTLY; IT'S THE OPERATOR FUNCTION IN THE POINT() CLASS THAT'S CAUSING THE PROBLEM. WHEN I COMMENT THEM OUT LINE AND CIRCLE OBJECTS WORK FINE
//LOOKS LIKE THE ABOVE ISSUE HAS BEEN SOLVED;

int main() {

	//Testing the << operator

	Point p1(4, 5);
	Point p2(9, 1);
	Point p3(30, 23);
	Line l1(p1,p2); //It's not reffering to the constructor with 2 Point arguments
	Circle c1(p2,4);
	
	//Testing the << operator functions for each independent class object
	std::cout << p1 << std::endl;
	std::cout << l1 << std::endl;
	std::cout << c1 << std::endl;



}