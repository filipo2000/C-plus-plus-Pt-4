#define _USE_MATH_DEFINES 
#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include "Circle.h"

//The define keyword should be a line above the cmath header file
//Objective -> In this file we define all the components within the Circle class

//If our function call returns a reference then our function call can be on the left side of an assignment (=) expression; Ex: fact() = d; where fact() is the function call is d is a variable

//Starting with our constructors and deconstructor
Circle::Circle() { //Since we are defining public members of the Circle class here we can freely include our private members of the Circle class
	Point();
	
}

Circle::Circle(Point a, double b) {
	m_point = a;
	m_radius = b;
}

Circle::Circle(const Circle& c) {
	m_point = c.m_point;
	m_radius = c.m_radius;
}

Circle::~Circle() {

}

//Get() Functions
Point Circle::CentrePoint() const {
	return m_point;
}

double Circle::Radius() const {
	return m_radius;
}

//Set() Functions
void Circle::CentrePoint(const Point& a) {
	m_point = a;
}

void Circle::Radius(const double& b) {
	m_radius = b;
}

//ToString() Function
std::string Circle::ToString() const {
	std::stringstream a, b;
	a << m_point.ToString();
	b << m_radius;
	std::string resi = "Circle with " + a.str() + "and radius " + b.str();
	return resi;
}

//Our Measurement Functions
double Circle::Area() const {
	return M_PI * pow(m_radius,2); //Area of a circle is pi * r^2
}

double Circle::Diameter() const {
	return m_radius * 2;
}

double Circle::Circumfrence() const {
	return 2 * M_PI * m_radius;
}

//Operator = function
Circle& Circle::operator=(const Circle& c) {
	if (this != &c) {
		m_point = c.m_point;
		m_radius = c.m_radius;
		return *this;
	}
	else {
		return *this;
	}
}

std::ostream& operator<<(std::ostream& o, const Circle& c) {
	o << c.ToString(); //Our ostream object here holds in it's buffer the string returned from the ToString() function in the Circle class
	return o;
}